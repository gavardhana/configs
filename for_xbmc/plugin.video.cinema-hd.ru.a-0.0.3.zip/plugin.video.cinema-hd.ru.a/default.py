#!/usr/bin/python
# -*- coding: utf-8 -*-

import urllib2
import urllib
import json
import xbmcgui
import xbmcplugin
import xbmcaddon
import re
import sys,os

from bs4 import BeautifulSoup as bs
from urlparse import parse_qs

Addon = xbmcaddon.Addon( id = 'plugin.video.cinema-hd.ru.a' )

addon_icon    = Addon.getAddonInfo('icon')
addon_fanart  = Addon.getAddonInfo('fanart')
addon_path    = Addon.getAddonInfo('path')
addon_id      = Addon.getAddonInfo('id')
addon_author  = Addon.getAddonInfo('author')
addon_name    = Addon.getAddonInfo('name')
addon_version = Addon.getAddonInfo('version')

try:
    sys.path.append(os.path.join(os.path.dirname(__file__), "../plugin.video.unified.search"))
    from unified_search import UnifiedSearch
except: pass

def get_params(paramstring):
    param=[]
    if len(paramstring)>=2:
        params=paramstring
        cleanedparams=params.replace('?','')
        if (params[len(params)-1]=='/'):
            params=params[0:len(params)-2]
        pairsofparams=cleanedparams.split('&')
        param={}
        for i in range(len(pairsofparams)):
            splitparams={}
            splitparams=pairsofparams[i].split('=')
            if (len(splitparams))==2:
                param[splitparams[0]]=splitparams[1]
    if len(param) > 0:
        for cur in param:
            param[cur] = urllib.unquote_plus(param[cur])
    return param

def GET(url,ref=None,opn=None,post=None):
    req = urllib2.Request(url,data=post)
    print "GET: " + url
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    req.add_header('Accept', '*/*')
    req.add_header('Accept-Language', 'ru-RU')
    req.add_header('Referer', ref)
    if opn == 'xmlhttp':
        req.add_header('X-Requested-With', 'XMLHttpRequest')
    if opn=='timeout':timeout=0.2
    else: timeout=5
    try:
        response = urllib2.urlopen(req,timeout=timeout)
        html=response.read()
        response.close()
        #print html
        return html
    except Exception, e:
        print 'GET: Error getting page '+url
        showMessage('HTTP Error','Error getting page '+url)
        return None

def construct_request(params):
    return '%s?%s' % (sys.argv[0], urllib.urlencode(params))
    
def showMessage(heading, message, times = 5000):
    xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s)'%(heading, message, times))

def touch(url):
    req = urllib2.Request(url)
    try:
        res=urllib2.urlopen(req)
        res.close()
        return True
    except:
        return False


def Search(params):
    kbd = xbmc.Keyboard()
    kbd.setDefault('')
    kbd.setHeading("Поиск")
    kbd.doModal()
    if kbd.isConfirmed():
        try:
            out = trans.detranslify(kbd.getText())
            out = str(out.encode("utf-8"))
        except:
            out = str(kbd.getText())
    uri={}
    uri['url']='board'
    uri['post']='query=%s&a=2'%out
    ListCat(uri)


def Main(params):
    listitem = xbmcgui.ListItem('Поиск',iconImage = addon_icon, thumbnailImage = addon_icon)
    uri = construct_request({
        'func': 'Search'
        })
    xbmcplugin.addDirectoryItem(hos, uri, listitem, True)

    listitem=xbmcgui.ListItem('НОВОЕ',iconImage = addon_icon, thumbnailImage = addon_icon)
    uri = construct_request({
        'func': 'ListCat',
        'url':'board/0-1'
        })
    xbmcplugin.addDirectoryItem(hos, uri, listitem, True)

    http = GET('http://cinema-hd.ru/')
    if http == None: return False
    soup = bs(http)
    content = soup.find('ol',attrs={'class':'dsitemmenu'})
    content=content.find_all('li')
    for num in content:
        title=num.find('a').string
        url=num.find('a')['href']
        listitem=xbmcgui.ListItem(title,iconImage = addon_icon, thumbnailImage = addon_icon)
        uri = construct_request({
            'func': 'ListCat',
            'url':url
            })
        if 'board' in url: xbmcplugin.addDirectoryItem(hos, uri, listitem, True)

    xbmcplugin.endOfDirectory(handle=hos, succeeded=True, updateListing=False, cacheToDisc=True)


def ListCat(params):
    if unified:
        params['url']='board'
        params['post']='query=%s&a=2'% params['keyword']
        unified_search_results=[]
    blink = 'http://cinema-hd.ru/' + params['url']
    post = params['post'] if 'post' in params else None
    if params['url']=='board':
        searchmode = True
        pq = 1
    else:
        searchmode = False
        pq = 3
    innerpage = int(params['page']) if 'page' in params else 1
    
    for page in range((innerpage-1)*pq+1,innerpage*pq+1):
        if page > 1:
            if re.search('board/0-1',blink): url = blink.replace('1',str(page))
            else: url = blink + '-' + str(page) + '-2'
        else: url = blink
        http = GET(url, post = post)
        soup = bs(http)
        content = soup.find_all('div', attrs={'id': re.compile('entryID[0-9]+')})
        for item in content:
            sdata = item.find('a', href=re.compile('http://cinema-hd.ru/board/.+'))
            #print sdata
            link = sdata['href']
            title = sdata.find('h2').string.encode('utf-8')
            print title
            img = item.find('img',width='250')['src']
            sdata1 = item.find_all('span',style="font-family:'Georgia'")
            genre = ' '.join(sdata1[1].stripped_strings).encode('utf-8')
            plot = ' '.join(sdata1[2].stripped_strings).encode('utf-8')
            uri = construct_request({
                'func': 'ListSeries',
                'url': link,
                'title': title,
                'img': img
                })
            if unified:
                usurl=re.compile(addon_id+'(.+)$').findall(uri)[0]
                uspath = {
                    'title': title,
                    'url': urllib.quote_plus(usurl),
                    'image': img,
                    'plugin': addon_id
                     }
                unified_search_results.append(uspath)
            else:
                li = xbmcgui.ListItem(title, iconImage = img, thumbnailImage = img)
                li.setInfo(type="video", infoLabels={"title":title, "plot": plot, "genre":genre})
                #listitem.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(hos, uri, li, True)
   
    if not searchmode:
        linp = xbmcgui.ListItem('Next page', iconImage = addon_icon, thumbnailImage = addon_icon)
        uri = construct_request({
            'func': 'ListCat',
            'page': innerpage+1,
            'url':params['url']
            })
        xbmcplugin.addDirectoryItem(hos, uri, linp, True)
    if unified:
        UnifiedSearch().collect(unified_search_results)
        return True
    xbmcplugin.setContent(hos, 'movies')
    xbmcplugin.endOfDirectory(handle=hos, succeeded=True, updateListing=False, cacheToDisc=True)


def ListSeries(params):
    http = GET(params['url'])
    soup = bs(http)
    content = soup.find('table',border="1",bordercolor="#1e1e1e",width="700",height="100",cellpadding="6",cellspacing="0",bgcolor="#1C1C1C")
    #print content
    bsdata = content.find_all('iframe')
    if len(bsdata)==0: bsdata = content.find_all('embed', allowscriptaccess="always", wmode="opaque")
    #print bsdata
    plot = content.find('span',itemprop="description")
    bsdata1 = plot.find_parent('table')
    plot = ' '.join(plot.stripped_strings).encode('utf-8')
    img = bsdata1.find('img',width="200",itemprop="image")['src']
    for iframe in bsdata:
        #Layout 1
        title=iframe.find_previous_sibling('span', style="color:#ff9900")
        #Layout 2
        if not title: title=iframe.find_parent('span', style="color:#ff9900")
        #Layout 3
        if not title:
            title=iframe.find_previous('font',color="ff9900")
            #Layout 4
            if title.font: title.font.decompose()
        
        title=list(title.stripped_strings)[0].encode('utf-8')
        url=iframe['src']
        #print title, url
        li = xbmcgui.ListItem(title, iconImage = addon_icon, thumbnailImage = img)
        uri = construct_request({
            'func': 'Play',
            'url': url
            })
        li.setInfo(type="video",infoLabels={"title": title, "plot": plot})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(hos, uri, li)

    xbmcplugin.endOfDirectory(handle = hos, succeeded = True, updateListing = False, cacheToDisc=True)


def Play(params):
	url = params['url']
	
	if url.find('ivi.ru') > -1:
		if xbmc.getCondVisibility('System.HasAddon(plugin.video.ivi.ru)')==0:
			showMessage("Cinema-hd.ru.a","Для просмотра необходим плагин ivi.ru")
			return True
		id = re.findall('videoId=(\d+)',url)
		if id:
			id = id[0]
			print "IVI.RU, id= " + str(id)
			link = "plugin://plugin.video.ivi.ru?func=playid&id="+id
			#xbmc.executebuiltin('XBMC.RunScript(plugin.video.ivi.ru,, ?func=playid&id=%s)'%(id))
		else:
			print "IVI.RU video id is not found, " + url
			return True
	else:
		link = GetVideo(url)
        if link==False: return True
	
	item = xbmcgui.ListItem(path=link)
	item.setProperty('IsPlayable', 'true')
	xbmcplugin.setResolvedUrl(hos, True, item)


def GetVideo(url):
	
	if url.find('vk.com') > -1:
		http=GET(url)
		soup = bs(http, from_encoding="windows-1251")
		#sdata1=soup.find('div',class_="scroll_fix_wrap",id="page_wrap")
		sdata1=soup.find('div',style="position:absolute; top:50%; text-align:center; right:0pt; left:0pt; font-family:Tahoma; font-size:12px; color:#777;")
		if sdata1:
			print sdata1.string.encode('utf-8')
			showMessage("Cinema-hd.ru.a",sdata1.string.encode('utf-8'))
			return False
		for rec in soup.find_all('param', {'name':'flashvars'}):
			fv={}
			for s in rec['value'].split('&'):
				sdd=s.split('=',1)
				fv[sdd[0]]=sdd[1]
				if s.split('=',1)[0] == 'uid':
					uid = s.split('=',1)[1]
				if s.split('=',1)[0] == 'vtag':
					vtag = s.split('=',1)[1]
				if s.split('=',1)[0] == 'host':
					host = s.split('=',1)[1]
				if s.split('=',1)[0] == 'vid':
					vid = s.split('=',1)[1]
				if s.split('=',1)[0] == 'oid':
					oid = s.split('=',1)[1]
				if s.split('=',1)[0] == 'hd':
					hd = s.split('=',1)[1]
			#print fv
			url = host+'u'+uid+'/videos/'+vtag+'.240.mp4'
			if int(hd)==3:
				url = host+'u'+uid+'/videos/'+vtag+'.720.mp4'
			if int(hd)==2:
				url = host+'u'+uid+'/videos/'+vtag+'.480.mp4'
			if int(hd)==1:
				url = host+'u'+uid+'/videos/'+vtag+'.360.mp4'
		print url
		if not touch(url):
			try:
				if int(hd)==3:
					url = fv['cache720']
				if int(hd)==2:
					url = fv['cache480']
				if int(hd)==1:
					url = fv['cache360']
			except:
				print 'Vk parser failed'
				showMessage("Cinema-hd.ru.a",'Vk parser failed!')
				return False
		#url = url.replace('vk.me','vk.com')
		return url
			
	if url.find('youtube.com') > -1:
		if url.find('//')==0: url=url[2:-1]
		try:
			url = get_yt(url)
			print url
		except Exception as ex:
			print ex
		return url


def get_yt(url):
	if url.find('youtube.com') > -1:
		if url.find('/videoseries?') > -1:
			print "youtube playlist"
			playlist_id=re.findall('list=(.+?)&',url)[0]
			print playlist_id
			info_url = "http://gdata.youtube.com/feeds/api/playlists/%s" % (playlist_id)
			#info_url = "http://www.youtube.com/view_play_list?p=%s" % (playlist_id)
			print info_url
			try:
				infopage = GET(info_url)
				videoinfo = parse_qs(infopage)
				#print type(videoinfo)
			except Exception as ex:
				print ex
			jso=videoinfo['app']
			links=[]
			for item in jso:
				#print item
				link=re.findall('media\:player url=\'(.+?)$',item)[0]
				#print link
				if link: links.append(get_yt(link))
			if links: video_url='stack://'+' , '.join(links)
			return video_url
		video_priority_map = {'38' : 1,'37' : 2,'22' : 3,'18' : 4,'35' : 5,'34' : 6,}
		video_url = url
		print url
		try:
			if url.find('youtube') > -1:
				found = False
				finder = url.find('=')
				video_id = url[finder + 1:]
				print video_id
				if url.find('/embed/')>-1:
					#print "embed"
					video_id=re.findall('embed/(.+?)\?',url)[0]
					#if video_id=="videoseries": video_id=re.findall('list=(.+?)&',url)[0]
					print video_id
				for el in ['&el=embedded',
				'&el=detailpage',
				'&el=vevo',
				'']:
					info_url = 'http://www.youtube.com/get_video_info?&video_id=%s%s&ps=default&eurl=&gl=US&hl=en' % (video_id, el)
					print info_url
					try:
						infopage = GET(info_url)
						videoinfo = parse_qs(infopage)
						print videoinfo
						if ('url_encoded_fmt_stream_map' or 'fmt_url_map') in videoinfo:
							found = True
							if 'use_cipher_signature' in videoinfo and videoinfo['use_cipher_signature'][0]=='True':
								print 'use_cipher_signature: '+ videoinfo['use_cipher_signature'][0]
								showMessage('use_cipher_signature:',videoinfo['use_cipher_signature'][0]) #FOR DEBUG
							break
					except Exception as ex:
						print ex

				if found:
					video_fmt_map = {}
					fmt_infomap = {}
					if videoinfo.has_key('url_encoded_fmt_stream_map'):
						tmp_fmtUrlDATA = videoinfo['url_encoded_fmt_stream_map'][0].split(',')
					else:
						tmp_fmtUrlDATA = videoinfo['fmt_url_map'][0].split(',')
					for fmtstring in tmp_fmtUrlDATA:
						fmturl = fmtid = fmtsig = ''
						#print fmtstring.split('&')
						if videoinfo.has_key('url_encoded_fmt_stream_map'):
							try:
								for arg in fmtstring.split('&'):
									print arg #FOR DEBUG
									if arg.find('=') >= 0:
										key, value = arg.split('=')
										if key == 'itag':
											if len(value) > 3:
												value = value[:2]
											fmtid = value
										elif key == 'url':
											fmturl = value
										elif key == 'sig':
											fmtsig = value

								if fmtid != '' and fmturl != '' and video_priority_map.has_key(fmtid):
									video_fmt_map[video_priority_map[fmtid]] = {'fmtid': fmtid,
									'fmturl': urllib.unquote_plus(fmturl)}
									#if fmtsig != '': video_fmt_map[video_priority_map[fmtid]]={'fmtid': fmtid,
									#'fmturl': urllib.unquote_plus(fmturl),'fmtsig': fmtsig}
									if fmtsig != '': video_fmt_map[video_priority_map[fmtid]]['fmtsig']=fmtsig
									fmt_infomap[int(fmtid)] = '%s' % (urllib.unquote_plus(fmturl))
									if fmtsig != '':fmt_infomap[int(fmtid)]+='&signature='+fmtsig
								fmturl = fmtid = fmtsig = ''
							except Exception as ex:
								#print type(ex).__name__
								print ex

						else:
							fmtid, fmturl = fmtstring.split('|')
						if video_priority_map.has_key(fmtid) and fmtid != '':
							video_fmt_map[video_priority_map[fmtid]] = {'fmtid': fmtid,
							'fmturl': urllib.unquote_plus(fmturl)}
							fmt_infomap[int(fmtid)] = urllib.unquote_plus(fmturl)

					if video_fmt_map and len(video_fmt_map):
						best_video = video_fmt_map[sorted(video_fmt_map.iterkeys())[0]]
						print best_video['fmturl']
						video_url = '%s' % (best_video['fmturl'].split(';')[0])
						if 'fmtsig' in best_video: video_url+='&signature='+best_video['fmtsig']
				else:
					print 'Youtube parser failed'
					showMessage("Youtube parser failed!",url)
		except Exception as ex:
			print ex

		if video_url != url:
			url = video_url
			#print url

	return url
         

hos = int(sys.argv[1])
params = get_params(sys.argv[2])
print sys.argv

# -- Unified search API handling --
unified = bool(params['unified']) if 'unified' in params else False
if unified:
    params['func']='ListCat'

mode = params["mode"] if 'mode' in params else None
if mode == 'show':
    print urllib.unquote_plus(params["url"])
    params = get_params(urllib.unquote_plus(params["url"]))
# ---------------------------------

try:
    func = params['func']
    del params['func']
except:
    func = None
    xbmc.log( '[%s]: Primary input' % addon_id, 1 )
    Main(params)
if func != None:
    try: pfunc = globals()[func]
    except:
        pfunc = None
        xbmc.log( '[%s]: Function "%s" not found' % (addon_id, func), 4 )
        showMessage('Internal addon error', 'Function "%s" not found' % func, 2000)
    if pfunc: pfunc(params)

